package com.smooth.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LauncherScreen(vm: AppsViewModel = viewModel()) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val dock by vm.dock.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 0 = home, 1 = app drawer. Everything animates off this single value.
    val progress = remember { Animatable(0f) }
    val drawerOpen by remember { derivedStateOf { progress.value > 0.01f } }
    var query by remember { mutableStateOf("") }
    val spec = remember { spring<Float>(dampingRatio = 0.82f, stiffness = 420f) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val travel = with(LocalDensity.current) { maxHeight.toPx() } * 0.6f

        fun move(dy: Float) {
            scope.launch { progress.snapTo((progress.value - dy / travel).coerceIn(0f, 1f)) }
        }

        fun settle(velocityY: Float) { // px/s, negative = swiping up
            val target = when {
                velocityY < -900f -> 1f
                velocityY > 900f -> 0f
                progress.value > 0.5f -> 1f
                else -> 0f
            }
            scope.launch {
                progress.animateTo(target, spec, initialVelocity = -velocityY / travel)
                if (target == 0f) query = ""
            }
        }

        BackHandler(enabled = drawerOpen) { settle(1000f) }

        // Home layer. All motion happens in graphicsLayer, so nothing recomposes per frame.
        Box(
            Modifier
                .fillMaxSize()
                .draggable(
                    state = rememberDraggableState { dy -> move(dy) },
                    orientation = Orientation.Vertical,
                    onDragStopped = { settle(it) },
                )
                .graphicsLayer {
                    val p = progress.value
                    scaleX = 1f - 0.08f * p
                    scaleY = scaleX
                    alpha = 1f - p
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                }
        ) {
            HomeLayer(dock) { context.launchApp(it) }
        }

        if (drawerOpen) {
            val nested = remember(travel) {
                object : NestedScrollConnection {
                    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                        if (available.y < 0f && progress.value < 1f) {
                            move(available.y); return Offset(0f, available.y)
                        }
                        return Offset.Zero
                    }
                    override fun onPostScroll(
                        consumed: Offset, available: Offset, source: NestedScrollSource,
                    ): Offset {
                        if (available.y > 0f) { move(available.y); return Offset(0f, available.y) }
                        return Offset.Zero
                    }
                    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                        if (progress.value < 0.999f) settle(available.y)
                        return available
                    }
                }
            }
            val filtered = remember(apps, query) {
                if (query.isBlank()) apps
                else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = progress.value
                        translationY = (1f - p) * travel
                        alpha = p
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                    }
                    .background(Color(0xB3000000))
                    .statusBarsPadding()
            ) {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search apps") },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = Color(0x33FFFFFF),
                        unfocusedContainerColor = Color(0x33FFFFFF),
                    ),
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding().nestedScroll(nested),
                ) {
                    items(filtered, key = { it.component.flattenToString() }, contentType = { "app" }) { app ->
                        AppIcon(app) { context.launchApp(app) }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeLayer(dock: List<AppItem>, onLaunch: (AppItem) -> Unit) {
    val time by produceState("") {
        val fmt = SimpleDateFormat("h:mm", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(5_000) }
    }
    val date by produceState("") {
        val fmt = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(60_000) }
    }
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 72.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(date, color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp)
            Text(time, color = Color.White, fontSize = 84.sp)
        }
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(Color(0x33FFFFFF))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            dock.forEach { AppIcon(it, showLabel = false) { onLaunch(it) } }
        }
    }
}

@Composable
private fun AppIcon(app: AppItem, showLabel: Boolean = true, onLaunch: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    // Bouncy press spring; read inside graphicsLayer so it never triggers recomposition.
    val scale = animateFloatAsState(
        targetValue = if (pressed) 0.84f else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 700f),
        label = "press",
    )
    Column(
        Modifier
            .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { onLaunch() },
                )
            }
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(60.dp))
        if (showLabel) {
            Text(
                app.label,
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
