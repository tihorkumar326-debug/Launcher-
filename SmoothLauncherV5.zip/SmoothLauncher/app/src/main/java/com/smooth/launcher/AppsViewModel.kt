package com.smooth.launcher

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

const val SLOT_COLS = 4
const val SLOT_ROWS = 4
const val SLOT_COUNT = SLOT_COLS * SLOT_ROWS

data class AppItem(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

fun Context.launchApp(app: AppItem) {
    val intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(app.component)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    startActivity(intent)
}

class AppsViewModel(application: Application) : AndroidViewModel(application) {
    private val pm = application.packageManager

    private val _apps = MutableStateFlow<List<AppItem>>(emptyList())
    val apps: StateFlow<List<AppItem>> = _apps.asStateFlow()

    private val _dock = MutableStateFlow<List<AppItem>>(emptyList())
    val dock: StateFlow<List<AppItem>> = _dock.asStateFlow()

    private val prefs = application.getSharedPreferences("home", Context.MODE_PRIVATE)

    /** Home-screen grid: component name per slot, null = empty. Saved on every change. */
    val slots = mutableStateListOf<String?>().apply {
        val saved = prefs.getString("slots", "").orEmpty().split("|")
        repeat(SLOT_COUNT) { add(saved.getOrNull(it)?.ifEmpty { null }) }
    }

    fun place(component: String, target: Int, from: Int) {
        if (target !in 0 until SLOT_COUNT) return
        val displaced = slots[target]
        slots[target] = component
        if (from in 0 until SLOT_COUNT) {
            slots[from] = if (from == target) component else displaced
        } else {
            for (i in slots.indices) if (i != target && slots[i] == component) slots[i] = null
        }
        save()
    }

    fun unpin(from: Int) {
        if (from in 0 until SLOT_COUNT) { slots[from] = null; save() }
    }

    private fun save() {
        prefs.edit().putString("slots", slots.joinToString("|") { it ?: "" }).apply()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = load()
    }

    init {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(application, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        load()
    }

    /** Icons are decoded once, off the main thread, so scrolling never decodes anything. */
    private fun load() {
        viewModelScope.launch(Dispatchers.Default) {
            val self = getApplication<Application>().packageName
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != self }
                .map { ri ->
                    val ai = ri.activityInfo
                    AppItem(
                        label = ri.loadLabel(pm).toString(),
                        pkg = ai.packageName,
                        component = ComponentName(ai.packageName, ai.name),
                        icon = ri.loadIcon(pm).toFullBleedBitmap().asImageBitmap(),
                    )
                }
                .sortedBy { it.label.lowercase() }
            _apps.value = list

            val picks = listOf(
                Intent(Intent.ACTION_DIAL),
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
                Intent(MediaStore.ACTION_IMAGE_CAPTURE),
            )
            val dockPkgs = picks.mapNotNull {
                pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            }.distinct()
            _dock.value = dockPkgs.mapNotNull { p -> list.firstOrNull { it.pkg == p } }.take(4)
        }
    }

    override fun onCleared() {
        getApplication<Application>().unregisterReceiver(receiver)
    }
}

private const val ICON_PX = 180

/** iOS-style icon: always a full square (the UI rounds the corners), never a small glyph on a plate. */
private fun Drawable.toFullBleedBitmap(): Bitmap {
    val bmp = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    if (this is AdaptiveIconDrawable) {
        val d = this
        val inset = (ICON_PX * 0.25f).toInt()
        // Layers are 108dp with a 72dp visible window; scale so the window fills the square.
        d.background?.let { it.setBounds(-inset, -inset, ICON_PX + inset, ICON_PX + inset); it.draw(canvas) }
        d.foreground?.let { it.setBounds(-inset, -inset, ICON_PX + inset, ICON_PX + inset); it.draw(canvas) }
    } else {
        canvas.drawColor(0xFF2C2C2E.toInt())
        val pad = (ICON_PX * 0.16f).toInt()
        setBounds(pad, pad, ICON_PX - pad, ICON_PX - pad)
        draw(canvas)
    }
    return bmp
}
