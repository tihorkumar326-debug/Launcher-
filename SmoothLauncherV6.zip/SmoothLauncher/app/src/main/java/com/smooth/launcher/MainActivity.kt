package com.smooth.launcher

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestHighestRefreshRate()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { LauncherScreen() }
        }
    }

    /** Ask the system for the display's fastest mode (90/120/144 Hz where available). */
    @Suppress("DEPRECATION")
    private fun requestHighestRefreshRate() {
        val display = if (Build.VERSION.SDK_INT >= 30) display else windowManager.defaultDisplay
        val best = display?.supportedModes?.maxByOrNull { it.refreshRate } ?: return
        window.attributes = window.attributes.apply { preferredDisplayModeId = best.modeId }
    }
}
