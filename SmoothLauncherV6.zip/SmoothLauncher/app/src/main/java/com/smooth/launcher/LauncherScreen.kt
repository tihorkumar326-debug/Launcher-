package com.smooth.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.net.Uri
import android.os.Process
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.graphics.Shadow
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.PointerEventPass
import kotlin.math.roundToInt

/** State of the icon currently being dragged (finger position is in root coordinates). */
private class DragController {
    var app by mutableStateOf<AppItem?>(null)
    var pos by mutableStateOf(Offset.Zero)
    var fromSlot = -1
    var moved = false
    var total = Offset.Zero
}

/** Where the home grid is on screen, used to turn a drop position into a slot. */
private class GridGeometry {
    var x = 0f
    var y = 0f
    var w = 1f
    var h = 1f
}

private class DragCallbacks(
    val start: (AppItem, Offset, Int) -> Unit,
    val move: (Offset) -> Unit,
    val end: () -> Boolean, // true = it was a real drag, false = just a long press
    val cancel: () -> Unit,
)

private val LabelStyle = TextStyle(
    shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 2f), 6f),
)

@Composable
fun LauncherScreen(vm: AppsViewModel = viewModel()) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val dock by vm.dock.collectAsStateWithLifecycle()
    val byComponent = remember(apps) { apps.associateBy { it.component.flattenToString() } }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val focusManager = LocalFocusManager.current
    val haptic = LocalHapticFeedback.current
    val searchFocus = remember { FocusRequester() }
    var focusSearch by remember { mutableStateOf(false) }
    var editOpen by remember { mutableStateOf(false) }
    val sheet = animateFloatAsState(
        targetValue = if (editOpen) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.85f, stiffness = 500f),
        label = "sheet",
    )

    // 0 = home, 1 = app drawer. Everything animates off this single value.
    val progress = remember { Animatable(0f) }
    val drawerOpen by remember { derivedStateOf { progress.value > 0.01f } }
    var query by remember { mutableStateOf("") }
    val spec = remember { spring<Float>(dampingRatio = 0.82f, stiffness = 420f) }

    val ctl = remember { DragController() }
    val geo = remember { GridGeometry() }
    val removePx = with(density) { 110.dp.toPx() }

    val callbacks = remember(removePx) {
        DragCallbacks(
            start = { app, pos, from ->
                ctl.fromSlot = from
                ctl.moved = false
                ctl.total = Offset.Zero
                ctl.pos = pos
                ctl.app = app
            },
            move = { d ->
                ctl.pos += d
                ctl.total += d
                if (!ctl.moved && ctl.total.getDistance() > 24f) {
                    ctl.moved = true
                    // Dragging out of the drawer: slide it away so the home grid is visible.
                    if (progress.value > 0f) scope.launch { progress.animateTo(0f, spec) }
                }
            },
            end = {
                val app = ctl.app
                val moved = ctl.moved
                if (app != null && moved) {
                    val gx = ctl.pos.x - geo.x
                    val gy = ctl.pos.y - geo.y
                    if (ctl.fromSlot >= 0 && ctl.pos.y < removePx) {
                        vm.unpin(ctl.fromSlot)
                    } else if (gx in 0f..geo.w && gy in 0f..geo.h) {
                        val col = (gx / (geo.w / SLOT_COLS)).toInt().coerceIn(0, SLOT_COLS - 1)
                        val row = (gy / (geo.h / SLOT_ROWS)).toInt().coerceIn(0, SLOT_ROWS - 1)
                        vm.place(app.component.flattenToString(), row * SLOT_COLS + col, ctl.fromSlot)
                    }
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    query = ""
                }
                ctl.app = null
                moved
            },
            cancel = { ctl.app = null },
        )
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val travel = with(density) { maxHeight.toPx() } * 0.6f

        fun move(dy: Float) {
            scope.launch { progress.snapTo((progress.value - dy / travel).coerceIn(0f, 1f)) }
        }

        fun settle(velocityY: Float) { // px/s, negative = swiping up
            val target = when {
                velocityY < -900f -> 1f
                velocityY > 900f -> 0f
                progress.value > 0.5f -> 1f
                else -> 0f
            }
            scope.launch {
                progress.animateTo(target, spec, initialVelocity = -velocityY / travel)
                if (target == 0f) { query = ""; focusManager.clearFocus() }
            }
        }

        BackHandler(enabled = drawerOpen) { settle(1000f) }
        BackHandler(enabled = editOpen) { editOpen = false }

        NovaBackground(vm.systemWallpaper)

        // Home layer. All motion happens in graphicsLayer, so nothing recomposes per frame.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    // Pinch-in (two fingers moving together) opens Edit Home Screen. Never consumes events.
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        var startDist = 0f
                        var fired = false
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val down = event.changes.filter { it.pressed }
                            if (down.size >= 2 && !fired) {
                                val d = (down[0].position - down[1].position).getDistance()
                                if (startDist == 0f) {
                                    startDist = d
                                } else if (d < startDist * 0.75f && progress.value < 0.01f && ctl.app == null) {
                                    fired = true
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    editOpen = true
                                }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .draggable(
                    state = rememberDraggableState { dy -> move(dy) },
                    orientation = Orientation.Vertical,
                    onDragStopped = { settle(it) },
                )
                .graphicsLayer {
                    val p = progress.value
                    scaleX = 1f - 0.08f * p
                    scaleY = scaleX
                    alpha = 1f - p
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                }
        ) {
            HomeLayer(
                dock, vm.slots, byComponent, callbacks, geo,
                onSearch = { focusSearch = true; scope.launch { progress.animateTo(1f, spec) } },
                onEdit = { editOpen = true },
            ) { context.launchApp(it) }
        }

        // Stay composed while an icon is being dragged out of the drawer.
        if (drawerOpen || ctl.app != null) {
            LaunchedEffect(focusSearch) {
                if (focusSearch) {
                    delay(60)
                    try { searchFocus.requestFocus() } catch (e: Exception) { }
                    focusSearch = false
                }
            }
            val nested = remember(travel) {
                object : NestedScrollConnection {
                    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                        if (available.y < 0f && progress.value < 1f) {
                            move(available.y); return Offset(0f, available.y)
                        }
                        return Offset.Zero
                    }
                    override fun onPostScroll(
                        consumed: Offset, available: Offset, source: NestedScrollSource,
                    ): Offset {
                        if (available.y > 0f) { move(available.y); return Offset(0f, available.y) }
                        return Offset.Zero
                    }
                    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                        if (progress.value < 0.999f) settle(available.y)
                        return available
                    }
                }
            }
            val filtered = remember(apps, query) {
                if (query.isBlank()) apps
                else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = progress.value
                        translationY = (1f - p) * travel
                        alpha = p
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                    }
                    .background(Color(0xD90A1025))
                    .statusBarsPadding()
                    .imePadding()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("App Library", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "✕",
                        color = Color.White,
                        fontSize = 24.sp,
                        modifier = Modifier.clickable { settle(1000f) },
                    )
                }
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        filtered.firstOrNull()?.let { context.launchApp(it); settle(1000f) }
                    }),
                    shape = RoundedCornerShape(20.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = Color(0x1FFFFFFF),
                        unfocusedContainerColor = Color(0x1FFFFFFF),
                    ),
                    modifier = Modifier.fillMaxWidth().padding(16.dp).focusRequester(searchFocus),
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding().nestedScroll(nested),
                ) {
                    items(filtered, key = { it.component.flattenToString() }, contentType = { "app" }) { app ->
                        AppIcon(app, drag = callbacks) { context.launchApp(app) }
                    }
                }
            }
        }

        // "Remove" strip, only while dragging an icon that is already on the home screen.
        if (ctl.app != null && ctl.fromSlot >= 0) {
            Box(
                Modifier.fillMaxWidth().height(110.dp).background(Color(0x66FF3B30)),
                contentAlignment = Alignment.Center,
            ) {
                Text("Drop here to remove", color = Color.White, fontSize = 16.sp)
            }
        }

        // The icon under your finger, drawn above everything.
        ctl.app?.let { dragged ->
            val half = with(density) { 30.dp.toPx() }
            Image(
                bitmap = dragged.icon,
                contentDescription = null,
                modifier = Modifier
                    .offset { IntOffset((ctl.pos.x - half).roundToInt(), (ctl.pos.y - half).roundToInt()) }
                    .size(60.dp)
                    .graphicsLayer { scaleX = 1.18f; scaleY = 1.18f; alpha = 0.96f }
                    .clip(RoundedCornerShape(22)),
            )
        }

        if (sheet.value > 0.01f) {
            EditSheet(
                visible = sheet.value,
                onWallpaper = {
                    vm.setSystemWallpaper(true)
                    editOpen = false
                    try {
                        context.startActivity(
                            Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Set wallpaper")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                    }
                },
                onNova = { vm.setSystemWallpaper(false); editOpen = false },
                onDismiss = { editOpen = false },
            )
        }
    }
}

@Composable
private fun EditSheet(visible: Float, onWallpaper: () -> Unit, onNova: () -> Unit, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = visible }
                .background(Color.Black.copy(alpha = 0.45f))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
                .graphicsLayer { translationY = (1f - visible) * 360.dp.toPx() }
                .background(Color(0xE610152B), RoundedCornerShape(28.dp))
                .glass(RoundedCornerShape(28.dp))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(vertical = 8.dp),
        ) {
            Text(
                "Edit Home Screen",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            )
            Text(
                "Change wallpaper",
                color = Color.White,
                fontSize = 17.sp,
                modifier = Modifier.fillMaxWidth().clickable { onWallpaper() }.padding(horizontal = 20.dp, vertical = 16.dp),
            )
            Text(
                "Use glass background",
                color = Color.White,
                fontSize = 17.sp,
                modifier = Modifier.fillMaxWidth().clickable { onNova() }.padding(horizontal = 20.dp, vertical = 16.dp),
            )
        }
    }
}

@Composable
private fun HomeLayer(
    dock: List<AppItem>,
    slots: List<String?>,
    byComponent: Map<String, AppItem>,
    drag: DragCallbacks,
    geo: GridGeometry,
    onSearch: () -> Unit,
    onEdit: () -> Unit,
    onLaunch: (AppItem) -> Unit,
) {
    val time by produceState("") {
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(5_000) }
    }
    val date by produceState("") {
        val fmt = SimpleDateFormat("EEEE, dd MMMM", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(60_000) }
    }
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding(),
            horizontalAlignment = Alignment.Start,
        ) {
            Spacer(Modifier.height(20.dp))
            Text(
                time,
                color = Color.White,
                fontSize = 76.sp,
                fontWeight = FontWeight.ExtraLight,
                letterSpacing = (-3).sp,
                modifier = Modifier
                    .pointerInput(Unit) { detectTapGestures(onLongPress = { onEdit() }) }
                    .padding(horizontal = 24.dp),
            )
            Text(
                date,
                color = Color.White.copy(alpha = 0.68f),
                fontSize = 16.sp,
                modifier = Modifier.padding(horizontal = 24.dp),
            )
            Spacer(Modifier.height(20.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
                    .onGloballyPositioned {
                        val p = it.positionInRoot()
                        geo.x = p.x
                        geo.y = p.y
                        geo.w = it.size.width.toFloat()
                        geo.h = it.size.height.toFloat()
                    }
            ) {
                repeat(SLOT_ROWS) { r ->
                    Row(Modifier.fillMaxWidth()) {
                        repeat(SLOT_COLS) { c ->
                            val idx = r * SLOT_COLS + c
                            Box(Modifier.weight(1f).height(96.dp), contentAlignment = Alignment.Center) {
                                val item = slots.getOrNull(idx)?.let { byComponent[it] }
                                if (item != null) {
                                    AppIcon(item, fromSlot = idx, drag = drag) { onLaunch(item) }
                                }
                            }
                        }
                    }
                }
            }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Search",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp,
                modifier = Modifier
                    .glass(RoundedCornerShape(50))
                    .clickable { onSearch() }
                    .padding(horizontal = 22.dp, vertical = 8.dp),
            )
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .glass(RoundedCornerShape(34.dp))
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                dock.forEach { AppIcon(it, showLabel = false) { onLaunch(it) } }
            }
        }
    }
}

@Composable
private fun AppIcon(
    app: AppItem,
    showLabel: Boolean = true,
    fromSlot: Int = -1,
    drag: DragCallbacks? = null,
    onLaunch: () -> Unit,
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var shortcuts by remember { mutableStateOf<List<ShortcutInfo>>(emptyList()) }
    val origin = remember { FloatArray(2) } // this icon's top-left in root coordinates

    LaunchedEffect(menuOpen) {
        if (menuOpen) shortcuts = withContext(Dispatchers.Default) { context.loadShortcuts(app.pkg) }
    }

    // Bouncy press spring; read inside graphicsLayer so it never triggers recomposition.
    val scale = animateFloatAsState(
        targetValue = if (pressed) 0.9f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 800f),
        label = "press",
    )
    Box(
        Modifier.onGloballyPositioned {
            val p = it.positionInRoot()
            origin[0] = p.x
            origin[1] = p.y
        }
    ) {
        Column(
            Modifier
                .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
                .pointerInput(drag == null) {
                    detectTapGestures(
                        onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                        onTap = { onLaunch() },
                        // Only icons that can't be dragged (the dock) open the menu on long press here.
                        onLongPress = if (drag == null) ({ _: Offset ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            menuOpen = true
                        }) else null,
                    )
                }
                .pointerInput(drag) {
                    if (drag != null) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { off ->
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                drag.start(app, Offset(origin[0], origin[1]) + off, fromSlot)
                            },
                            onDrag = { change, amount ->
                                change.consume()
                                drag.move(amount)
                            },
                            // Released without moving: show the menu instead of dropping.
                            onDragEnd = { if (!drag.end()) menuOpen = true },
                            onDragCancel = { drag.cancel() },
                        )
                    }
                }
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier.size(60.dp).clip(RoundedCornerShape(22)),
            )
            if (showLabel) {
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = LabelStyle,
                    modifier = Modifier.padding(top = 5.dp),
                )
            }
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            shortcuts.forEach { sc ->
                DropdownMenuItem(
                    text = { Text(sc.shortLabel?.toString() ?: sc.id) },
                    onClick = { menuOpen = false; context.startShortcut(sc) },
                )
            }
            DropdownMenuItem(
                text = { Text("App info") },
                onClick = {
                    menuOpen = false
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", app.pkg, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
            )
            DropdownMenuItem(
                text = { Text("Uninstall") },
                onClick = {
                    menuOpen = false
                    context.startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
            )
        }
    }
}

/** App shortcuts (e.g. "New tab"). Only readable while this app is the default home app. */
private fun Context.loadShortcuts(pkg: String): List<ShortcutInfo> = try {
    val la = getSystemService(LauncherApps::class.java)
    val q = LauncherApps.ShortcutQuery()
        .setPackage(pkg)
        .setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
        )
    la.getShortcuts(q, Process.myUserHandle())?.filter { it.isEnabled }?.take(4) ?: emptyList()
} catch (e: Exception) {
    emptyList()
}

private fun Context.startShortcut(sc: ShortcutInfo) {
    try {
        getSystemService(LauncherApps::class.java).startShortcut(sc, null, null)
    } catch (e: Exception) {
    }
}

/** Frosted-glass surface: soft gradient fill plus a thin light border. */
private fun Modifier.glass(shape: Shape): Modifier = this
    .clip(shape)
    .background(
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.19f),
                Color.White.copy(alpha = 0.045f),
                Color(0xFF849EFF).copy(alpha = 0.09f),
            )
        )
    )
    .border(1.dp, Color.White.copy(alpha = 0.22f), shape)

/**
 * Deep navy backdrop with two slowly drifting glowing orbs. Drawn as radial gradients in the
 * draw phase (no blur, no recomposition), so the animation costs almost nothing.
 */
@Composable
private fun NovaBackground(system: Boolean) {
    if (system) {
        // Real system wallpaper shows through; a light scrim keeps text readable.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.25f), Color.Black.copy(alpha = 0.08f), Color.Black.copy(alpha = 0.35f))
                )
            )
        )
        return
    }
    val t = rememberInfiniteTransition(label = "liquid").animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(5_500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "orb",
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF080B19))
            .drawBehind {
                val drift = t.value * 40.dp.toPx()
                val r1 = 230.dp.toPx()
                val r2 = 220.dp.toPx()
                val c1 = Offset(size.width * 0.2f + drift, size.height * 0.2f)
                val c2 = Offset(size.width * 0.85f - drift, size.height * 0.55f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF6558FF).copy(alpha = 0.6f), Color.Transparent),
                        center = c1,
                        radius = r1,
                    ),
                    radius = r1,
                    center = c1,
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF00C8FF).copy(alpha = 0.45f), Color.Transparent),
                        center = c2,
                        radius = r2,
                    ),
                    radius = r2,
                    center = c2,
                )
            }
    )
}
