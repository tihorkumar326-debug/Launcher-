# Smooth Launcher

Kotlin + Jetpack Compose home-screen launcher focused on motion quality.

## Build
1. Android Studio (Koala or newer): File > Open > this folder. Let Gradle sync.
2. Run on a device. Press Home and choose Smooth Launcher > Always.
3. For real smoothness testing use a **release** build (Build > Select Build Variant > release,
   signed with your debug key). Debug builds are noticeably slower.

## What makes it feel smooth
- One progress value drives the whole home/drawer transition; it is read only inside
  graphicsLayer, so dragging causes zero recomposition.
- Spring physics seeded with the finger's release velocity (motion continues naturally).
- Drawer composed only while visible; ModulateAlpha avoids offscreen buffers.
- Icons decoded once on a background thread into ImageBitmaps; stable keys for the grid.
- Nested scrolling hands the drawer from grid scroll to close-drag seamlessly.
- Requests the display's highest refresh rate (90/120 Hz).
- NOVA-style liquid-glass look: the drifting orbs are radial gradients drawn in the draw phase (no blur, no recomposition).

## V5 (iOS-style pass)
- Full-bleed squircle icons (no grey plate), label shadows, bigger icons
- Wide frosted dock, iOS-style Search pill (opens App Library with keyboard), Search key launches first match
- Haptic on drop, softer press spring

## V6
- Pinch in (or long-press the clock) opens Edit Home Screen: change wallpaper (system picker) or switch back to the glass background

## Next steps
Baseline Profile (big first-launch win), widgets, folders, long-press menus, icon packs.
