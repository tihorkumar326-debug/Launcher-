package com.smooth.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.net.Uri
import android.os.Process
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** State of the icon currently being dragged (finger position is in root coordinates). */
private class DragController {
    var app by mutableStateOf<AppItem?>(null)
    var pos by mutableStateOf(Offset.Zero)
    var fromSlot = -1
    var moved = false
    var total = Offset.Zero
}

/** Where the home grid is on screen, used to turn a drop position into a slot. */
private class GridGeometry {
    var x = 0f
    var y = 0f
    var w = 1f
    var h = 1f
}

private class DragCallbacks(
    val start: (AppItem, Offset, Int) -> Unit,
    val move: (Offset) -> Unit,
    val end: () -> Boolean, // true = it was a real drag, false = just a long press
    val cancel: () -> Unit,
)

@Composable
fun LauncherScreen(vm: AppsViewModel = viewModel()) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val dock by vm.dock.collectAsStateWithLifecycle()
    val byComponent = remember(apps) { apps.associateBy { it.component.flattenToString() } }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    // 0 = home, 1 = app drawer. Everything animates off this single value.
    val progress = remember { Animatable(0f) }
    val drawerOpen by remember { derivedStateOf { progress.value > 0.01f } }
    var query by remember { mutableStateOf("") }
    val spec = remember { spring<Float>(dampingRatio = 0.82f, stiffness = 420f) }

    val ctl = remember { DragController() }
    val geo = remember { GridGeometry() }
    val removePx = with(density) { 110.dp.toPx() }

    val callbacks = remember(removePx) {
        DragCallbacks(
            start = { app, pos, from ->
                ctl.fromSlot = from
                ctl.moved = false
                ctl.total = Offset.Zero
                ctl.pos = pos
                ctl.app = app
            },
            move = { d ->
                ctl.pos += d
                ctl.total += d
                if (!ctl.moved && ctl.total.getDistance() > 24f) {
                    ctl.moved = true
                    // Dragging out of the drawer: slide it away so the home grid is visible.
                    if (progress.value > 0f) scope.launch { progress.animateTo(0f, spec) }
                }
            },
            end = {
                val app = ctl.app
                val moved = ctl.moved
                if (app != null && moved) {
                    val gx = ctl.pos.x - geo.x
                    val gy = ctl.pos.y - geo.y
                    if (ctl.fromSlot >= 0 && ctl.pos.y < removePx) {
                        vm.unpin(ctl.fromSlot)
                    } else if (gx in 0f..geo.w && gy in 0f..geo.h) {
                        val col = (gx / (geo.w / SLOT_COLS)).toInt().coerceIn(0, SLOT_COLS - 1)
                        val row = (gy / (geo.h / SLOT_ROWS)).toInt().coerceIn(0, SLOT_ROWS - 1)
                        vm.place(app.component.flattenToString(), row * SLOT_COLS + col, ctl.fromSlot)
                    }
                    query = ""
                }
                ctl.app = null
                moved
            },
            cancel = { ctl.app = null },
        )
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val travel = with(density) { maxHeight.toPx() } * 0.6f

        fun move(dy: Float) {
            scope.launch { progress.snapTo((progress.value - dy / travel).coerceIn(0f, 1f)) }
        }

        fun settle(velocityY: Float) { // px/s, negative = swiping up
            val target = when {
                velocityY < -900f -> 1f
                velocityY > 900f -> 0f
                progress.value > 0.5f -> 1f
                else -> 0f
            }
            scope.launch {
                progress.animateTo(target, spec, initialVelocity = -velocityY / travel)
                if (target == 0f) query = ""
            }
        }

        BackHandler(enabled = drawerOpen) { settle(1000f) }

        // Home layer. All motion happens in graphicsLayer, so nothing recomposes per frame.
        Box(
            Modifier
                .fillMaxSize()
                .draggable(
                    state = rememberDraggableState { dy -> move(dy) },
                    orientation = Orientation.Vertical,
                    onDragStopped = { settle(it) },
                )
                .graphicsLayer {
                    val p = progress.value
                    scaleX = 1f - 0.08f * p
                    scaleY = scaleX
                    alpha = 1f - p
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                }
        ) {
            HomeLayer(dock, vm.slots, byComponent, callbacks, geo) { context.launchApp(it) }
        }

        // Stay composed while an icon is being dragged out of the drawer.
        if (drawerOpen || ctl.app != null) {
            val nested = remember(travel) {
                object : NestedScrollConnection {
                    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                        if (available.y < 0f && progress.value < 1f) {
                            move(available.y); return Offset(0f, available.y)
                        }
                        return Offset.Zero
                    }
                    override fun onPostScroll(
                        consumed: Offset, available: Offset, source: NestedScrollSource,
                    ): Offset {
                        if (available.y > 0f) { move(available.y); return Offset(0f, available.y) }
                        return Offset.Zero
                    }
                    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                        if (progress.value < 0.999f) settle(available.y)
                        return available
                    }
                }
            }
            val filtered = remember(apps, query) {
                if (query.isBlank()) apps
                else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = progress.value
                        translationY = (1f - p) * travel
                        alpha = p
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                    }
                    .background(Color(0xB3000000))
                    .statusBarsPadding()
            ) {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search apps") },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = Color(0x33FFFFFF),
                        unfocusedContainerColor = Color(0x33FFFFFF),
                    ),
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding().nestedScroll(nested),
                ) {
                    items(filtered, key = { it.component.flattenToString() }, contentType = { "app" }) { app ->
                        AppIcon(app, drag = callbacks) { context.launchApp(app) }
                    }
                }
            }
        }

        // "Remove" strip, only while dragging an icon that is already on the home screen.
        if (ctl.app != null && ctl.fromSlot >= 0) {
            Box(
                Modifier.fillMaxWidth().height(110.dp).background(Color(0x66FF3B30)),
                contentAlignment = Alignment.Center,
            ) {
                Text("Drop here to remove", color = Color.White, fontSize = 16.sp)
            }
        }

        // The icon under your finger, drawn above everything.
        ctl.app?.let { dragged ->
            val half = with(density) { 36.dp.toPx() }
            Image(
                bitmap = dragged.icon,
                contentDescription = null,
                modifier = Modifier
                    .offset { IntOffset((ctl.pos.x - half).roundToInt(), (ctl.pos.y - half).roundToInt()) }
                    .size(72.dp)
                    .graphicsLayer { scaleX = 1.1f; scaleY = 1.1f; alpha = 0.95f },
            )
        }
    }
}

@Composable
private fun HomeLayer(
    dock: List<AppItem>,
    slots: List<String?>,
    byComponent: Map<String, AppItem>,
    drag: DragCallbacks,
    geo: GridGeometry,
    onLaunch: (AppItem) -> Unit,
) {
    val time by produceState("") {
        val fmt = SimpleDateFormat("h:mm", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(5_000) }
    }
    val date by produceState("") {
        val fmt = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(60_000) }
    }
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(24.dp))
            Text(date, color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp)
            Text(time, color = Color.White, fontSize = 64.sp)
            Spacer(Modifier.height(16.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
                    .onGloballyPositioned {
                        val p = it.positionInRoot()
                        geo.x = p.x
                        geo.y = p.y
                        geo.w = it.size.width.toFloat()
                        geo.h = it.size.height.toFloat()
                    }
            ) {
                repeat(SLOT_ROWS) { r ->
                    Row(Modifier.fillMaxWidth()) {
                        repeat(SLOT_COLS) { c ->
                            val idx = r * SLOT_COLS + c
                            Box(Modifier.weight(1f).height(92.dp), contentAlignment = Alignment.Center) {
                                val item = slots.getOrNull(idx)?.let { byComponent[it] }
                                if (item != null) {
                                    AppIcon(item, fromSlot = idx, drag = drag) { onLaunch(item) }
                                }
                            }
                        }
                    }
                }
            }
        }
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(Color(0x33FFFFFF))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            dock.forEach { AppIcon(it, showLabel = false) { onLaunch(it) } }
        }
    }
}

@Composable
private fun AppIcon(
    app: AppItem,
    showLabel: Boolean = true,
    fromSlot: Int = -1,
    drag: DragCallbacks? = null,
    onLaunch: () -> Unit,
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var shortcuts by remember { mutableStateOf<List<ShortcutInfo>>(emptyList()) }
    val origin = remember { FloatArray(2) } // this icon's top-left in root coordinates

    LaunchedEffect(menuOpen) {
        if (menuOpen) shortcuts = withContext(Dispatchers.Default) { context.loadShortcuts(app.pkg) }
    }

    // Bouncy press spring; read inside graphicsLayer so it never triggers recomposition.
    val scale = animateFloatAsState(
        targetValue = if (pressed) 0.84f else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 700f),
        label = "press",
    )
    Box(
        Modifier.onGloballyPositioned {
            val p = it.positionInRoot()
            origin[0] = p.x
            origin[1] = p.y
        }
    ) {
        Column(
            Modifier
                .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
                .pointerInput(drag == null) {
                    detectTapGestures(
                        onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                        onTap = { onLaunch() },
                        // Only icons that can't be dragged (the dock) open the menu on long press here.
                        onLongPress = if (drag == null) ({ _: Offset ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            menuOpen = true
                        }) else null,
                    )
                }
                .pointerInput(drag) {
                    if (drag != null) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { off ->
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                drag.start(app, Offset(origin[0], origin[1]) + off, fromSlot)
                            },
                            onDrag = { change, amount ->
                                change.consume()
                                drag.move(amount)
                            },
                            // Released without moving: show the menu instead of dropping.
                            onDragEnd = { if (!drag.end()) menuOpen = true },
                            onDragCancel = { drag.cancel() },
                        )
                    }
                }
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(60.dp))
            if (showLabel) {
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            shortcuts.forEach { sc ->
                DropdownMenuItem(
                    text = { Text(sc.shortLabel?.toString() ?: sc.id) },
                    onClick = { menuOpen = false; context.startShortcut(sc) },
                )
            }
            DropdownMenuItem(
                text = { Text("App info") },
                onClick = {
                    menuOpen = false
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", app.pkg, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
            )
            DropdownMenuItem(
                text = { Text("Uninstall") },
                onClick = {
                    menuOpen = false
                    context.startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
            )
        }
    }
}

/** App shortcuts (e.g. "New tab"). Only readable while this app is the default home app. */
private fun Context.loadShortcuts(pkg: String): List<ShortcutInfo> = try {
    val la = getSystemService(LauncherApps::class.java)
    val q = LauncherApps.ShortcutQuery()
        .setPackage(pkg)
        .setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
        )
    la.getShortcuts(q, Process.myUserHandle())?.filter { it.isEnabled }?.take(4) ?: emptyList()
} catch (e: Exception) {
    emptyList()
}

private fun Context.startShortcut(sc: ShortcutInfo) {
    try {
        getSystemService(LauncherApps::class.java).startShortcut(sc, null, null)
    } catch (e: Exception) {
    }
}
